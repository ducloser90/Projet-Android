package com.example.DergaouiAyoub;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Profile extends AppCompatActivity {

    private EditText fullnameEditText, emailEditText, mdpEditText, ageEditText, majorEditText ,phoneEditText;
    private RadioGroup genderRadioGroup;
    private RadioButton maleRadioButton, femaleRadioButton;
    private Button  changeProfileButton;
    private ImageView backButton ;
    private TextView confirmButton ;
    private SQLiteDatabase database;
    private ImageView profileImageView;
    private String profilePhotoPath;
    private static final int REQUEST_IMAGE_CAPTURE = 1;
    private static final int REQUEST_SELECT_IMAGE = 2;
    private Bitmap profileImageBitmap;
    private ImageView passwordToggle;
    private boolean isPasswordVisible = false;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        // Initialize views
        fullnameEditText = findViewById(R.id.fullname);
        emailEditText = findViewById(R.id.email);
        mdpEditText = findViewById(R.id.mdp);
        ageEditText = findViewById(R.id.age);
        majorEditText = findViewById(R.id.Major);
        phoneEditText=findViewById(R.id.Phone);
        genderRadioGroup = findViewById(R.id.genderRadioGroup);
        maleRadioButton = findViewById(R.id.maleRadioButton);
        femaleRadioButton = findViewById(R.id.femaleRadioButton);
        confirmButton = findViewById(R.id.Confirmer);
        backButton = findViewById(R.id.backButton);
        changeProfileButton = findViewById(R.id.changeProfileButton);
        profileImageView = findViewById(R.id.profileImageView);
        passwordToggle = findViewById(R.id.passwordToggle);

        passwordToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isPasswordVisible) {
                    // If password is visible, hide it and change the icon
                    mdpEditText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    passwordToggle.setImageResource(R.drawable.baseline_visibility_off_24);
                    isPasswordVisible = false;
                } else {
                    // If password is hidden, show it and change the icon
                    mdpEditText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                    passwordToggle.setImageResource(R.drawable.baseline_visibility_24);
                    isPasswordVisible = true;
                }
                // Move the cursor to the end of the text
                mdpEditText.setSelection(mdpEditText.getText().length());
            }
        });



        // Retrieve user information passed from previous activity
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String fullname = extras.getString("full_name");
            String email = extras.getString("email");
            String password = extras.getString("mdp"); // Assuming you also pass password
            int age = extras.getInt("age", 0);
            String major = extras.getString("major");
            String phone = extras.getString("phone");
            String gender = extras.getString("gender");
            profilePhotoPath = extras.getString("photo");

            // Set user information in the form
            fullnameEditText.setText(fullname);
            emailEditText.setText(email);
            mdpEditText.setText(password); // Note: It's not recommended to pre-fill password EditText for security reasons
            ageEditText.setText(String.valueOf(age));
            majorEditText.setText(major);
            phoneEditText.setText(phone);
            if (gender != null) {
                if (gender.equals("Male")) {
                    maleRadioButton.setChecked(true);
                } else if (gender.equals("Female")) {
                    femaleRadioButton.setChecked(true);
                }
            }
            // Set profile photo if available
            if (profilePhotoPath != null && !profilePhotoPath.isEmpty()) {
                // Convert the path to a URI
                Uri photoUri = Uri.parse(profilePhotoPath);
                // Set the URI to the ImageView
                profileImageView.setImageURI(photoUri);
            }

        }


        database = openOrCreateDatabase("Accounts_DB", MODE_PRIVATE, null);
        database.execSQL("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, full_name TEXT, email TEXT, mdp TEXT, Age INTEGER, phone TEXT, major TEXT,  gender TEXT, photo TEXT, userActivity TEXT)");


        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Navigate back to the Menu activity and pass user information and photo
                String fullname = fullnameEditText.getText().toString().trim();
                String email = emailEditText.getText().toString().trim();
                String password = mdpEditText.getText().toString().trim();
                int age = Integer.parseInt(ageEditText.getText().toString().trim());
                String major = majorEditText.getText().toString().trim();
                String phone=phoneEditText.getText().toString().trim();
                String gender = (genderRadioGroup.getCheckedRadioButtonId() == R.id.maleRadioButton) ? "Male" : "Female";

                Intent intent = new Intent(Profile.this, Menu.class);
                intent.putExtra("full_name", fullname);
                intent.putExtra("email", email);
                intent.putExtra("mdp", password);
                intent.putExtra("age", age);
                intent.putExtra("phone", phone);
                intent.putExtra("major", major);
                intent.putExtra("gender", gender);
                intent.putExtra("photo", profilePhotoPath);
                startActivity(intent);
            }
        });

        changeProfileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Display dialog to choose between taking a photo and selecting from the gallery
                AlertDialog.Builder builder = new AlertDialog.Builder(Profile.this);
                builder.setTitle("Choose an option")
                        .setItems(new CharSequence[]{"Take a photo", "Choose from gallery"}, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                switch (which) {
                                    case 0:
                                        // Take a photo
                                        dispatchTakePictureIntent();
                                        break;
                                    case 1:
                                        // Choose from gallery
                                        Intent selectImageIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                                        startActivityForResult(selectImageIntent, REQUEST_SELECT_IMAGE);
                                        break;
                                }
                            }
                        });
                builder.show();
            }
        });

        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get updated information from EditText fields
                String newFullName = fullnameEditText.getText().toString().trim();
                String newEmail = emailEditText.getText().toString().trim();
                String newPassword = mdpEditText.getText().toString().trim();
                int newAge = Integer.parseInt(ageEditText.getText().toString().trim());
                String newPhone=phoneEditText.getText().toString().trim();
                String newMajor = majorEditText.getText().toString().trim();
                String newGender = (genderRadioGroup.getCheckedRadioButtonId() == R.id.maleRadioButton) ? "Male" : "Female";

                // Update user information in the database
                updateUserInfoInDatabase(newFullName, newEmail, newPassword, newAge,newPhone, newMajor, newGender);

                // Update user photo path in the database
                updateProfilePhotoPathInDatabase();

                // Show a Toast to notify the user
                Toast.makeText(Profile.this, "Your information has been updated", Toast.LENGTH_SHORT).show();

                // Send the updated information back to the Menu activity
                Intent intent = new Intent(Profile.this, Menu.class);
                intent.putExtra("email", newEmail);
                intent.putExtra("mdp", newPassword);
                intent.putExtra("age", newAge);
                intent.putExtra("major", newMajor);
                intent.putExtra("phone", newPhone);
                intent.putExtra("gender", newGender);
                intent.putExtra("photo", profilePhotoPath);
                startActivity(intent);
            }
        });

    }

    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        }
    }

    private void updateUserInfoInDatabase(String fullname, String email, String password, int age,String phone ,String major, String gender) {
        // Open the database for writing

        SQLiteDatabase database = openOrCreateDatabase("Accounts_DB", MODE_PRIVATE, null);


        // Create ContentValues object to store updated values
        ContentValues values = new ContentValues();
        values.put("full_name", fullname);
        values.put("email", email);
        values.put("mdp", password);
        values.put("Age", age);
        values.put("phone", phone);
        values.put("major", major);
        values.put("gender", gender);

        // Update the row in the database based on email
        database.update("users", values, "email=?", new String[]{email});

        // Close the database
        database.close();
    }

    private void updateProfilePhotoPathInDatabase() {
        // Open the database for writing
        SQLiteDatabase database = openOrCreateDatabase("Accounts_DB", MODE_PRIVATE, null);

        // Create ContentValues object to store updated photo path
        ContentValues values = new ContentValues();
        values.put("photo", profilePhotoPath);

        // Update the row in the database based on email
        database.update("users", values, "email=?", new String[]{emailEditText.getText().toString().trim()});

        // Close the database
        database.close();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            profileImageBitmap = (Bitmap) extras.get("data");
            profileImageView.setImageBitmap(profileImageBitmap);
            // Save the photo to a file
            saveProfilePhoto();
        } else if (requestCode == REQUEST_SELECT_IMAGE && resultCode == RESULT_OK) {
            Uri selectedImageUri = data.getData();
            try {
                profileImageBitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImageUri);
                profileImageView.setImageBitmap(profileImageBitmap);
                // Save the photo to a file
                saveProfilePhoto();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void saveProfilePhoto() {
        // Generate a unique file name for the profile photo
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        try {
            // Create a file in the cache directory
            File storageDir = getCacheDir();
            File imageFile = File.createTempFile(
                    imageFileName,
                    ".jpg",
                    storageDir
            );
            // Save the bitmap to the file
            FileOutputStream fos = new FileOutputStream(imageFile);
            profileImageBitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
            fos.flush();
            fos.close();
            // Set the profile photo path
            profilePhotoPath = imageFile.getAbsolutePath();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
