package com.example.DergaouiAyoub;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class UserActivity extends Activity implements SensorEventListener {
    private static final int TIME_STAMP = 100;
    private static final String TAG = "UserActivity";

    private static List<Float> ax, ay, az;
    private static List<Float> gx, gy, gz;
    private static List<Float> lx, ly, lz;

    private SensorManager mSensorManager;
    private Sensor mAccelerometer, mGyroscope, mLinearAcceleration;

    private float[] results;
    private ActivityClassifier classifier;

    private TextView bikingTextView, downstairsTextView, joggingTextView, sittingTextView, standingTextView, upstairsTextView, walkingTextView;
    private ImageView backButton;

    // Declare the ExecutorService for background tasks
    private ExecutorService executorService;
    private Future<?> predictionFuture;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activite);

        initLayoutItems();

        // Initialize lists for sensor data
        ax = new ArrayList<>();
        ay = new ArrayList<>();
        az = new ArrayList<>();
        gx = new ArrayList<>();
        gy = new ArrayList<>();
        gz = new ArrayList<>();
        lx = new ArrayList<>();
        ly = new ArrayList<>();
        lz = new ArrayList<>();

        executorService = Executors.newSingleThreadExecutor();

        mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        mAccelerometer = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        mGyroscope = mSensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        mLinearAcceleration = mSensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);

        classifier = new ActivityClassifier(getApplicationContext());

        // Register listeners only if sensors are available
        if (mAccelerometer != null) {
            mSensorManager.registerListener(this, mAccelerometer, SensorManager.SENSOR_DELAY_FASTEST);
        }
        if (mGyroscope != null) {
            mSensorManager.registerListener(this, mGyroscope, SensorManager.SENSOR_DELAY_FASTEST);
        }
        if (mLinearAcceleration != null) {
            mSensorManager.registerListener(this, mLinearAcceleration, SensorManager.SENSOR_DELAY_FASTEST);
        }

        /*backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ActivtyIntent = new Intent(UserActivity.this, Menu.class);
                startActivity(ActivtyIntent);
            }
        });*/
    }

    private void initLayoutItems() {
        bikingTextView = findViewById(R.id.biking_TextView);
        downstairsTextView = findViewById(R.id.downstairs_TextView);
        joggingTextView = findViewById(R.id.jogging_TextView);
        sittingTextView = findViewById(R.id.sitting_TextView);
        standingTextView = findViewById(R.id.standing_TextView);
        upstairsTextView = findViewById(R.id.upstairs_TextView);
        walkingTextView = findViewById(R.id.walking_TextView);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        Sensor sensor = event.sensor;
        if (sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            Log.d(TAG, "Accelerometer: " + Arrays.toString(event.values));
            ax.add(event.values[0]);
            ay.add(event.values[1]);
            az.add(event.values[2]);
        } else if (sensor.getType() == Sensor.TYPE_GYROSCOPE) {
            Log.d(TAG, "Gyroscope: " + Arrays.toString(event.values));
            gx.add(event.values[0]);
            gy.add(event.values[1]);
            gz.add(event.values[2]);
        } else if (sensor.getType() == Sensor.TYPE_LINEAR_ACCELERATION) {
            Log.d(TAG, "Linear Acceleration: " + Arrays.toString(event.values));
            lx.add(event.values[0]);
            ly.add(event.values[1]);
            lz.add(event.values[2]);
        }

        // Schedule the prediction task if not already running
        if (predictionFuture == null || predictionFuture.isDone()) {
            predictionFuture = executorService.submit(() -> {
                if (ax.size() >= TIME_STAMP && ay.size() >= TIME_STAMP && az.size() >= TIME_STAMP
                        && gx.size() >= TIME_STAMP && gy.size() >= TIME_STAMP && gz.size() >= TIME_STAMP
                        && lx.size() >= TIME_STAMP && ly.size() >= TIME_STAMP && lz.size() >= TIME_STAMP) {

                    List<Float> data = new ArrayList<>();
                    data.addAll(ax.subList(0, TIME_STAMP));
                    data.addAll(ay.subList(0, TIME_STAMP));
                    data.addAll(az.subList(0, TIME_STAMP));
                    data.addAll(gx.subList(0, TIME_STAMP));
                    data.addAll(gy.subList(0, TIME_STAMP));
                    data.addAll(gz.subList(0, TIME_STAMP));
                    data.addAll(lx.subList(0, TIME_STAMP));
                    data.addAll(ly.subList(0, TIME_STAMP));
                    data.addAll(lz.subList(0, TIME_STAMP));

                    Log.d(TAG, "Data for Prediction: " + Arrays.toString(toFloatArray(data)));

                    float[] results = classifier.predictProbabilities(toFloatArray(data));
                    Log.i(TAG, "Predicted Probabilities: " + Arrays.toString(results));

                    // Update UI on the main thread
                    runOnUiThread(() -> updateTextViews(results));

                    // Clear the data lists after processing
                    ax.clear();
                    ay.clear();
                    az.clear();
                    gx.clear();
                    gy.clear();
                    gz.clear();
                    lx.clear();
                    ly.clear();
                    lz.clear();
                } else {
                    Log.d(TAG, "Not enough data to predict.");
                }
            });
        }
    }



    private float[] toFloatArray(List<Float> data) {
        int i=0;
        float[] array=new float[data.size()];
        for (Float f:data) {
            array[i++] = (f != null ? f: Float.NaN);
        }
        return array;
    }

    private void updateTextViews(float[] results) {
        String activity = getActivityLabel(results);
        Log.d(TAG, "Updating TextViews with results: " + Arrays.toString(results));
        bikingTextView.setText("" + round(results[0], 2));
        downstairsTextView.setText("" + round(results[1], 2));
        joggingTextView.setText("" + round(results[2], 2));
        sittingTextView.setText("" + round(results[3], 2));
        standingTextView.setText("" + round(results[4], 2));
        upstairsTextView.setText("" + round(results[5], 2));
        walkingTextView.setText("" + round(results[6], 2));

        Intent intent = new Intent("UPDATE_ACTIVITY");
        intent.putExtra("activity", activity);
        LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(intent);

    }

    private float round(float value, int decimal_places) {
        BigDecimal bigDecimal = new BigDecimal(Float.toString(value));
        bigDecimal = bigDecimal.setScale(decimal_places, BigDecimal.ROUND_HALF_UP);
        return bigDecimal.floatValue();
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Not used in this example
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Register sensors again if needed
        if (mAccelerometer != null) {
            mSensorManager.registerListener(this, mAccelerometer, SensorManager.SENSOR_DELAY_FASTEST);
        }
        if (mGyroscope != null) {
            mSensorManager.registerListener(this, mGyroscope, SensorManager.SENSOR_DELAY_FASTEST);
        }
        if (mLinearAcceleration != null) {
            mSensorManager.registerListener(this, mLinearAcceleration, SensorManager.SENSOR_DELAY_FASTEST);
        }
    }




    @Override
    protected void onDestroy() {
        super.onDestroy();
        mSensorManager.unregisterListener(this);
        // Shutdown the executor service to clean up resources
        if (executorService != null) {
            executorService.shutdown();
        }
    }

    private String getActivityLabel(float[] results) {
        String[] activities = {"Biking", "Downstairs", "Jogging", "Sitting", "Standing", "Upstairs", "Walking"};
        int maxIndex = 0;
        for (int i = 1; i < results.length; i++) {
            if (results[i] > results[maxIndex]) {
                maxIndex = i;
            }
        }
        return activities[maxIndex];
    }
}
