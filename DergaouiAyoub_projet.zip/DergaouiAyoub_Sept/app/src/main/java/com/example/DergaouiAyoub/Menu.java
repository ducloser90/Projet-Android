package com.example.DergaouiAyoub;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;

import java.io.File;
import java.util.ArrayList;

public class Menu extends AppCompatActivity {
    /*private CardView Profile, Activity, Map;*/
    private CardView logout, Profile, Activity, Map;
    private String fullname, email, mdp;
    private int age;
    private String major, phone;
    private String gender;
    private String photoFilePath;
    private ImageView profileImageView;
    private SQLiteDatabase database;


    private FusedLocationProviderClient fusedLocationClient;
    private ArrayList<Double> latitudes = new ArrayList<>();
    private ArrayList<Double> longitudes = new ArrayList<>();
    private boolean firstLocationReceived = false;

    private static final String CHANNEL_ID = "location_service_channel";

    @SuppressLint({"MissingInflatedId", "WrongViewCast", "Range"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        createNotificationChannel();

        profileImageView = findViewById(R.id.profileImageView);


        // Retrieve data from MainActivity
        Intent intent = getIntent();
        fullname = intent.getStringExtra("full_name");
        email = intent.getStringExtra("email");
        mdp = intent.getStringExtra("mdp");
        age = intent.getIntExtra("age", 0);
        major = intent.getStringExtra("major");
        phone = intent.getStringExtra("phone");
        gender = intent.getStringExtra("gender");

        // Open the database
        database = openOrCreateDatabase("Accounts_DB", MODE_PRIVATE, null);
        // Retrieve photo file path from the database based on email
        Cursor cursor = database.rawQuery("SELECT full_name, photo FROM users WHERE email = ?", new String[]{email});
        if (cursor.moveToFirst()) {
            photoFilePath = cursor.getString(cursor.getColumnIndex("photo"));
            fullname = cursor.getString(cursor.getColumnIndex("full_name"));
            TextView fullnameTextView = findViewById(R.id.fullnameTextView);
            fullnameTextView.setText(fullname);

            // Load the photo into the ImageView
            if (photoFilePath != null) {
                File imgFile = new File(photoFilePath);
                if (imgFile.exists()) {
                    Glide.with(this)
                            .load(imgFile)
                            .into(profileImageView);
                }
            }
        }
        cursor.close();


        logout = findViewById(R.id.Disconnect);
        Profile = findViewById(R.id.Profile);
        Activity = findViewById(R.id.Activity);
        Map = findViewById(R.id.Map);





        logout.setOnClickListener(v -> {
            cancelLocationServiceNotification();
            Intent intent1 = new Intent(Menu.this, MainActivity.class);
            intent1.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent1);
            finish();
            Toast.makeText(Menu.this, "You are Successfully Disconnected!", Toast.LENGTH_SHORT).show();
        });


        Profile.setOnClickListener(v -> {
            cancelLocationServiceNotification();
            Intent profileIntent = new Intent(Menu.this, Profile.class);
            profileIntent.putExtra("full_name", fullname);
            profileIntent.putExtra("email", email);
            profileIntent.putExtra("mdp", mdp);
            profileIntent.putExtra("age", age);
            profileIntent.putExtra("phone", phone);
            profileIntent.putExtra("major", major);
            profileIntent.putExtra("gender", gender);
            profileIntent.putExtra("photo", photoFilePath);
            startActivity(profileIntent);
        });

        Activity.setOnClickListener(v -> {
            cancelLocationServiceNotification();
            Intent ActivtyIntent = new Intent(Menu.this, UserActivity.class);
            startActivity(ActivtyIntent);
        });

        Map.setOnClickListener(v -> {
            showLocationServiceNotification();
            Intent mapIntent = new Intent(Menu.this, Localisation.class);
            startActivity(mapIntent);
        });
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Location Service Channel";
            String description = "Channel for location service notifications";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);

            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    private void showLocationServiceNotification() {
        Intent notificationIntent = new Intent(this, Menu.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Location Service")
                .setContentText("Location service is running")
                .setSmallIcon(R.drawable.mainlogo)
                .setContentIntent(pendingIntent)
                .build();

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        notificationManager.notify(1, notification);
    }

    private void cancelLocationServiceNotification() {
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        notificationManager.cancel(1);
    }



    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

    }
}


