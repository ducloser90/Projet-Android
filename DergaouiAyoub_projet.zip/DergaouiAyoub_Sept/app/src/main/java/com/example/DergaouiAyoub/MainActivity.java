package com.example.DergaouiAyoub;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText email, mdp;
    private Button SeConnecter, register;
    private SQLiteDatabase database;
    private ImageView passwordToggle;
    private boolean isPasswordVisible = false;



    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initLayoutItems();

        passwordToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isPasswordVisible) {
                    // If password is visible, hide it and change the icon
                    mdp.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    passwordToggle.setImageResource(R.drawable.baseline_visibility_off_24);
                    isPasswordVisible = false;
                } else {
                    // If password is hidden, show it and change the icon
                    mdp.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                    passwordToggle.setImageResource(R.drawable.baseline_visibility_24);
                    isPasswordVisible = true;
                }
                // Move the cursor to the end of the text
                mdp.setSelection(mdp.getText().length());
            }
        });

        // Create or open the database
        database = openOrCreateDatabase("Accounts_DB", MODE_PRIVATE, null);

        database.execSQL("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, full_name TEXT, email TEXT, mdp TEXT, Age INTEGER, phone TEXT, major TEXT,  gender TEXT, photo TEXT, userActivity TEXT)");


        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Register.class);
                startActivity(intent);
            }
        });

        SeConnecter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String enteredEmail = email.getText().toString().trim();
                String enteredPassword = mdp.getText().toString().trim();

                // Check if email or password is empty
                if (enteredEmail.isEmpty() || enteredPassword.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter email and password", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Query the database
                Cursor cursor = database.rawQuery("SELECT * FROM users WHERE email = ? AND mdp = ?", new String[]{enteredEmail, enteredPassword});

                if (cursor.moveToFirst()) {
                    // Retrieve user information from the cursor
                    @SuppressLint("Range") String storedFullName = cursor.getString(cursor.getColumnIndex("full_name"));
                    @SuppressLint("Range") String storedEmail = cursor.getString(cursor.getColumnIndex("email"));
                    @SuppressLint("Range") String storedMdp = cursor.getString(cursor.getColumnIndex("mdp"));
                    @SuppressLint("Range") int age = cursor.getInt(cursor.getColumnIndex("Age"));
                    @SuppressLint("Range") String phone = cursor.getString(cursor.getColumnIndex("phone"));
                    @SuppressLint("Range") String major = cursor.getString(cursor.getColumnIndex("major"));
                    @SuppressLint("Range") String gender = cursor.getString(cursor.getColumnIndex("gender"));
                    @SuppressLint("Range") String photoPath = cursor.getString(cursor.getColumnIndex("photo"));

                    // Navigate to MenuActivity and pass user information
                    Intent intent = new Intent(MainActivity.this, Menu.class);
                    intent.putExtra("full_name", storedFullName);
                    intent.putExtra("email", storedEmail);
                    intent.putExtra("mdp", storedMdp);
                    intent.putExtra("age", age);
                    intent.putExtra("phone", phone);
                    intent.putExtra("major", major);
                    intent.putExtra("gender", gender);
                    intent.putExtra("photoPath", photoPath);
                    startActivity(intent);
                } else {
                    // If user not found, show error message
                    Toast.makeText(MainActivity.this, "Invalid email or password", Toast.LENGTH_SHORT).show();
                }

                // Close the cursor after use
                cursor.close();



            }
        });

    }

    private void initLayoutItems() {
        email = findViewById(R.id.email);
        mdp = findViewById(R.id.mdp);
        register = findViewById(R.id.Register);
        SeConnecter = findViewById(R.id.SeConnecter);
        passwordToggle = findViewById(R.id.passwordToggle);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        moveTaskToBack(true);
    }

}




