package com.example.DergaouiAyoub;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Register extends AppCompatActivity {
    private EditText fullname, email, mdp, major, age, phone;
    private RadioGroup genderRadioGroup;
    private Button confirmer, changeProfileButton;
    private ImageView profilPhoto;
    private SQLiteDatabase database;
    private static final int REQUEST_IMAGE_CAPTURE = 1;
    private static final int REQUEST_SELECT_IMAGE = 2;
    private String profilePhotoPath;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Requesting permissions at runtime
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 0);
        }

        fullname = findViewById(R.id.fullname);
        email = findViewById(R.id.email);
        mdp = findViewById(R.id.mdp);
        major = findViewById(R.id.Major);
        age = findViewById(R.id.age);
        phone = findViewById(R.id.Phone);
        genderRadioGroup = findViewById(R.id.genderRadioGroup);
        confirmer = findViewById(R.id.Confirmer);
        changeProfileButton = findViewById(R.id.changeProfileButton);
        profilPhoto = findViewById(R.id.profileImageView);

        database = openOrCreateDatabase("Accounts_DB", MODE_PRIVATE, null);
        database.execSQL("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, full_name TEXT, email TEXT, mdp TEXT, Age INTEGER, phone TEXT, major TEXT,  gender TEXT, photo TEXT, userActivity TEXT)");

        confirmer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String FullName = fullname.getText().toString().trim();
                String Email = email.getText().toString().trim();
                String Mdp = mdp.getText().toString().trim();
                String Phone = phone.getText().toString().trim();
                String Major = major.getText().toString().trim();
                String Age = age.getText().toString().trim();
                String vide = "Historique :";

                int selectedRadioButtonId = genderRadioGroup.getCheckedRadioButtonId();
                if (selectedRadioButtonId == -1) {
                    Toast.makeText(Register.this, "Please select your gender", Toast.LENGTH_SHORT).show();
                    return;
                }
                RadioButton selectedRadioButton = findViewById(selectedRadioButtonId);
                String Gender = selectedRadioButton.getText().toString();

                if (FullName.isEmpty() || Email.isEmpty() || Mdp.isEmpty() || Major.isEmpty() || Age.isEmpty() || Phone.isEmpty()) {
                    Toast.makeText(Register.this, "Please fill all the fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                ContentValues values = new ContentValues();
                values.put("full_name", FullName);
                values.put("email", Email);
                values.put("mdp", Mdp);
                values.put("phone", Phone);
                values.put("major", Major);
                values.put("Age", Age);
                values.put("gender", Gender);
                values.put("photo", profilePhotoPath);
                //values.put("calories_distance_Date", vide);
                long newRowId = database.insert("users", null, values);

                if (newRowId != -1) {
                    Toast.makeText(Register.this, "User registered successfully!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(Register.this, MainActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(Register.this, "Error!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        changeProfileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                builder.setTitle("Choose an option")
                        .setItems(new CharSequence[]{"Take a photo", "Choose from gallery"}, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                if (which == 0) {
                                    dispatchTakePictureIntent();
                                } else {
                                    Intent selectImageIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                                    startActivityForResult(selectImageIntent, REQUEST_SELECT_IMAGE);
                                }
                            }
                        });
                builder.show();
            }
        });
    }

    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        }
    }

    private String savePhotoToInternalStorage(Bitmap bitmap) {
        ContextWrapper cw = new ContextWrapper(getApplicationContext());
        File directory = cw.getDir("imageDir", Context.MODE_PRIVATE);

        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String fileName = "profile_" + timeStamp + ".jpg";

        File mypath = new File(directory, fileName);

        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(mypath);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (fos != null) {
                    fos.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return directory.getAbsolutePath() + "/" + fileName;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            Bitmap profileImageBitmap = (Bitmap) extras.get("data");
            profilPhoto.setImageBitmap(profileImageBitmap);
            profilePhotoPath = savePhotoToInternalStorage(profileImageBitmap);
        } else if (requestCode == REQUEST_SELECT_IMAGE && resultCode == RESULT_OK) {
            Uri selectedImageUri = data.getData();
            try {
                Bitmap profileImageBitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImageUri);
                profilPhoto.setImageBitmap(profileImageBitmap);
                profilePhotoPath = savePhotoToInternalStorage(profileImageBitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
